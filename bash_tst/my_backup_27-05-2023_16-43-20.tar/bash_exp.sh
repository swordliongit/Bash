#!/bin/bash

# Author: Kılıçarslan SIMSIKI
# Date Created: 18/05/2023
# Last Modified: 18/05/2023

# Description
#

# Usage
# 

echo "hello world"

exit 0